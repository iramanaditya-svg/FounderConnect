import ProfessionalProfile from "../models/professionalProfile.model.js";
import User from "../models/user.model.js";

import asyncHandler from "../utils/asyncHandler.js";
import ApiError from "../utils/ApiError.js";
import ApiResponse from "../utils/ApiResponse.js";
import { JobApplication } from "../models/jobApplication.model.js";

const createProfessionalProfile = asyncHandler(async (req, res) => {
    const {
        headline,
        skills,
        experience,
        education,
        resume,
        github,
        linkedin,
        portfolio,
    } = req.body;

    if (!headline?.trim()) {
        throw new ApiError(400, "Headline is required");
    }

    const user = await User.findById(req.user._id);

    if (!user) {
        throw new ApiError(404, "User not found");
    }

    if (user.activeRole !== "professional") {
        throw new ApiError(
            403,
            "Switch to Professional role first"
        );
    }

    const existingProfile = await ProfessionalProfile.findOne({
        user: user._id,
    });

if (existingProfile) {
    user.isProfileCompleted = true;

    await user.save({
        validateBeforeSave: false,
    });

    return res.status(200).json(
        new ApiResponse(
            200,
            {
                professionalProfile: existingProfile,
                user,
            },
            "Professional profile already exists"
        )
    );
}

    const professionalProfile = await ProfessionalProfile.create({
        user: user._id,
        headline,
        skills,
        experience,
        education,
        resume,
        github,
        linkedin,
        portfolio,
    });

    user.activeRole = "professional";

user.isProfileCompleted = true;

await user.save({
    validateBeforeSave: false,
});

    return res.status(201).json(
        new ApiResponse(
            201,
            professionalProfile,
            "Professional profile created successfully"
        )
    );
});

const getProfessionalProfile = asyncHandler(async (req, res) => {
const user = await User.findById(req.user._id);

const professionalProfile = await ProfessionalProfile.findOne({
    user: req.user._id,
});

if (!professionalProfile) {
    throw new ApiError(404, "Professional profile not found");
}

return res.status(200).json(
    new ApiResponse(
        200,
        {
            professionalProfile,
            user,
        },
        "Professional profile fetched successfully"
    )
);
});

const updateProfessionalProfile = asyncHandler(async (req, res) => {
const {
    headline,
    skills,
    experience,
    education,
    github,
    linkedin,
    portfolio,
    resume,
} = req.body;

    const professionalProfile =
        await ProfessionalProfile.findOne({
            user: req.user._id,
        });

    if (!professionalProfile) {
        throw new ApiError(
            404,
            "Professional profile not found"
        );
    }

    if (headline !== undefined && !headline.trim()) {
        throw new ApiError(
            400,
            "Headline cannot be empty"
        );
    }


    professionalProfile.headline =
    headline ?? professionalProfile.headline;

professionalProfile.skills =
    skills ?? professionalProfile.skills;

professionalProfile.experience =
    experience ?? professionalProfile.experience;

professionalProfile.education =
    education ?? professionalProfile.education;

professionalProfile.github =
    github ?? professionalProfile.github;

professionalProfile.linkedin =
    linkedin ?? professionalProfile.linkedin;

professionalProfile.portfolio =
    portfolio ?? professionalProfile.portfolio;

professionalProfile.resume =
    resume ?? professionalProfile.resume;
    await professionalProfile.save();

    return res.status(200).json(
        new ApiResponse(
            200,
            professionalProfile,
            "Professional profile updated successfully"
        )
    );
});

const deleteProfessionalProfile = asyncHandler(async (req, res) => {
    const user = await User.findById(req.user._id);

    if (!user) {
        throw new ApiError(
            404,
            "User not found"
        );
    }

    const hasActiveApplications =
        await JobApplication.exists({
            applicant: req.user._id,
            status: {
                $in: [
                    "pending",
                    "shortlisted",
                ],
            },
        });

    if (hasActiveApplications) {
        throw new ApiError(
            400,
            "You cannot delete your Professional profile while you have active job applications"
        );
    }

    await ProfessionalProfile.deleteOne({
        user: req.user._id,
    });

    user.roles = user.roles.filter(
        (role) => role !== "professional"
    );

    user.activeRole =
        user.roles[0] ?? null;

    if (user.roles.length === 0) {
        user.isProfileCompleted = false;
    }

    await user.save({
        validateBeforeSave: false,
    });

    return res.status(200).json(
        new ApiResponse(
            200,
            {
                roles: user.roles,
                activeRole: user.activeRole,
            },
            "Professional role deleted successfully"
        )
    );
});
export { createProfessionalProfile, getProfessionalProfile, updateProfessionalProfile, deleteProfessionalProfile };